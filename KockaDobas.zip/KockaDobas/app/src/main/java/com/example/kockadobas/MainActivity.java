package com.example.kockadobas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView jatekos_image, gep_image;
    private Random rand;
    private int jatekos_pont, gep_pont;
    private TextView eredmeny;
    private Button dobas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        dobas.setOnClickListener((View.OnClickListener) this);
    }

    private void init()
    {
        jatekos_image = findViewById(R.id.jatekos_kocka);
        gep_image = findViewById(R.id.gep_kocka);
        eredmeny = findViewById(R.id.text_eredmeny);
        dobas = findViewById(R.id.dobas);
        rand = new Random();
        jatekos_pont = 0;
        gep_pont = 0;
    }


    public void onClick(View v)
    {
        int jatekoskockaszam = rand.nextInt(6);
        jatekoskockaszam++;
        int gepkockaszam = rand.nextInt(6);
        gepkockaszam++;
        if(jatekoskockaszam > gepkockaszam)
        {
            jatekos_pont++;
            Toast.makeText(MainActivity.this, "Te nyertél", Toast.LENGTH_SHORT).show();
        }
        else if(gepkockaszam > jatekoskockaszam)
        {
            gep_pont++;
            Toast.makeText(MainActivity.this, "A gép nyert", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(MainActivity.this, "Döntetlen", Toast.LENGTH_SHORT).show();
        }

        if(jatekoskockaszam == 1)
        {
            jatekos_image.setImageResource(R.drawable.kocka1);
        }else if(jatekoskockaszam == 2)
        {
            jatekos_image.setImageResource(R.drawable.kocka2);
        }else if(jatekoskockaszam == 3)
        {
            jatekos_image.setImageResource(R.drawable.kocka3);
        }else if(jatekoskockaszam == 4)
        {
            jatekos_image.setImageResource(R.drawable.kocka4);
        }else if(jatekoskockaszam == 5)
        {
            jatekos_image.setImageResource(R.drawable.kocka5);
        }else if(jatekoskockaszam == 6)
        {
            jatekos_image.setImageResource(R.drawable.kocka6);
        }

        if(gepkockaszam == 1)
        {
            gep_image.setImageResource((R.drawable.kocka1));
        }else if(gepkockaszam == 2)
        {
            gep_image.setImageResource((R.drawable.kocka2));
        }else if(gepkockaszam == 3)
        {
            gep_image.setImageResource((R.drawable.kocka3));
        }else if(gepkockaszam == 4)
        {
            gep_image.setImageResource((R.drawable.kocka4));
        }else if(gepkockaszam == 5)
        {
            gep_image.setImageResource((R.drawable.kocka5));
        }else if(gepkockaszam == 6)
        {
            gep_image.setImageResource((R.drawable.kocka6));
        }

        eredmeny.setText(String.format("Eredmény: " + jatekos_pont + "-" + gep_pont));

        if(gep_pont == 3)
        {
            Toast.makeText(MainActivity.this, "A játékot a gépnyerte", Toast.LENGTH_LONG).show();
            gep_pont = 0;
            jatekos_pont = 0;

        }else if(jatekos_pont == 3)
        {
            Toast.makeText(MainActivity.this, "A játékot te nyerted", Toast.LENGTH_LONG).show();
            gep_pont = 0;
            jatekos_pont = 0;
        }

    }




}
